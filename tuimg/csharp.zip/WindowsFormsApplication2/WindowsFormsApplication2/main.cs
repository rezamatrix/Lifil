﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class main : Form
    {
        string login1;
        string mac1;
        public main(string login, string mac)
        {
            InitializeComponent();
            login1 = login;
            mac1 = mac;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            if (login1 == "ok")
            {
                label1.Text = "به نرم افزار ما خوش آمدید";
                label2.Text = "مک آدرس شما" + mac1;
            }
        }
    }
}
