﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Management;

namespace WindowsFormsApplication2
{
    public partial class main : Form
    {
        string login1;
        string mac1;
        CookieContainer a1;
        public main(string login, string mac ,CookieContainer a)
        {
            InitializeComponent();
            login1 = login;
            mac1 = mac;
            a1 = a;

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            if (login1 == "ok")
            {

                CookieAwareWebClient client = new CookieAwareWebClient(a1);
                var text = client.DownloadString("http://bitsoftware.ir/apiv2/fc.php?key=seeasdvy");
                label1.Text = text;
                label2.Text = "" + mac1;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            string uuid = string.Empty;

            ManagementClass mc = new ManagementClass("Win32_ComputerSystemProduct");
            ManagementObjectCollection moc = mc.GetInstances();

            foreach (ManagementObject mo in moc)
            {
                uuid = mo.Properties["UUID"].Value.ToString();
                break;
            }
            CookieAwareWebClient client1 = new CookieAwareWebClient(a1);
            var text2s = client1.DownloadString("http://bitsoftware.ir/apiv2/getset.php?con=" + uuid);
            if (text2s != "ok")
            {
                login r1 = new login();
                r1.Show();
                this.Close();
            }
        }
    }
}
