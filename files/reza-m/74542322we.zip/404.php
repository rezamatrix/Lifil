<?php
/**
 * The template for displaying 404 pages(not found).
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package VG Genius
 */

get_header('404'); ?>
<div class="page-content">
	<h2><?php esc_html_e('404', 'vg-genius'); ?></h2>
	<h3><?php esc_html_e('PAGE NOT FOUND', 'vg-genius'); ?></h3>
	<label>
		<?php esc_html_e('You can go back to', 'vg-genius');?> 
		<a href="<?php echo esc_url(home_url('/')); ?>"> 
			<?php esc_html_e('Homepage', 'vg-genius');?>
		</a>
		<?php esc_html_e('or search what you are looking for', 'vg-genius');?>
	</label>
	<?php get_search_form(); ?>
</div>
<?php get_footer('404'); ?>
