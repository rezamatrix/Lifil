<?php

echo "reza";
// header('location:../../login.php'); 


?>