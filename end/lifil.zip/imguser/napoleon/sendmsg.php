<?php
include("conf.php");
if(isset($_POST['send'])){
$text=urlencode($_POST['twp_channel_pattern']);
$ptext=$_POST['pass'];
$rang=$_POST['rang'];
$sql = "INSERT INTO `sender` (`matn`, `therd`, `therd2`) VALUES ('$text', '0', '0');";
$resultz = $conn->query($sql);
$result2 = $conn->insert_id;
$sql = "SELECT chatid FROM `user`";
$result = $conn->query($sql);
$sqlq = "SELECT matn,therd FROM `sender` WHERE `id` = $result2";
$resultq = $conn->query($sqlq);
$ee=$resultq->fetch_array();
$e1=$ee['matn'];
$e2=$ee['therd'];

if($ptext=='reza@1375'){
    $i=0;
if ($result->num_rows > 0) {
    while($row =$result->fetch_array()){
       if(strlen($row['chatid'])>5){
     $cid[$i]=$row['chatid'];
        $i++;
       }
    }
    $f=count($cid);
    for($j=0+$rang;$j<=$f;$j++){
       if(strlen($cid[$j])>5){
      $sqlqs = "UPDATE `sender` SET `therd` = therd + 1 WHERE `id` = $result2";
$resultqs = $conn->query($sqlqs);
        @file_get_contents("https://api.telegram.org/bot301300774:AAFhH8ZticWbTHDFgq4lJHuaDKoTkCxMU60/sendMessage?chat_id=".$cid[$j]."&text=".$e1."&disable_notification=true");
       }
   }
    }
    }
   }
  if(isset($_GET['id'])){
$id=$_GET['id'];
$sqlq = "SELECT matn,therd FROM `sender` WHERE `id` = $id";
$resultq = $conn->query($sqlq);
$ee=$resultq->fetch_array();
$e1=$ee['matn'];
$e2=$ee['therd'];
$text=$e1;
$rang=$e2;
$sql = "SELECT chatid FROM `user`";
$result = $conn->query($sql);
    $i=0;
if ($result->num_rows > 0) {
    while($row =$result->fetch_array()){
       if(strlen($row['chatid'])>5){
     $cid[$i]=$row['chatid'];
        $i++;
       }
    }
    $f=count($cid);
    for($j=0+$rang;$j<=$f;$j++){
       if(strlen($cid[$j])>5){
      $sqlqs = "UPDATE `sender` SET `therd` = therd + 1 WHERE `id` = $id";
$resultqs = $conn->query($sqlqs);
        @file_get_contents("https://api.telegram.org/bot301300774:AAFhH8ZticWbTHDFgq4lJHuaDKoTkCxMU60/sendMessage?chat_id=".$cid[$j]."&text=".$e1."&disable_notification=true");
       }
   }
    }

  }
   ?>


						<span title=':smile:'>😄</span>
						<span title=':smiley:'>😃</span>
						<span title=':grinning:'>😀</span>
						<span title=':blush:'>😊</span>
						<span title=':relaxed:'>☺️</span>
						<span title=':wink:'>😉</span>
						<span title=':heart_eyes:'>😍</span>
						<span title=':kissing_heart:'>😘</span>
						<span title=':kissing_closed_eyes:'>😚</span>
						<span title=':kissing:'>😗</span>
						<span title=':kissing_smiling_eyes:'>😙</span>
						<span title=':stuck_out_tongue_winking_eye:'>😜</span>
						<span title=':stuck_out_tongue_closed_eyes:'>😝</span>
						<span title=':stuck_out_tongue:'>😛</span>
						<span title=':flushed:'>😳</span>
						<span title=':grin:'>😁</span>
						<span title=':pensive:'>😔</span>
						<span title=':relieved:'>😌</span>
						<span title=':unamused:'>😒</span>
						<span title=':disappointed:'>😞</span>
						<span title=':persevere:'>😣</span>
						<span title=':cry:'>😢</span>
						<span title=':joy:'>😂</span>
						<span title=':sob:'>😭</span>
						<span title=':sleepy:'>😪</span>
						<span title=':disappointed_relieved:'>😥</span>
						<span title=':cold_sweat:'>😰</span>
						<span title=':sweat_smile:'>😅</span>
						<span title=':sweat:'>😓</span>
						<span title=':weary:'>😩</span>
						<span title=':tired_face:'>😫</span>
						<span title=':fearful:'>😨</span>
						<span title=':scream:'>😱</span>
						<span title=':angry:'>😠</span>
						<span title=':rage:'>😡</span>
						<span title=':triumph:'>😤</span>
						<span title=':confounded:'>😖</span>
						<span title=':laughing:'>😆</span>
						<span title=':yum:'>😋</span>
						<span title=':mask:'>😷</span>
						<span title=':sunglasses:'>😎</span>
						<span title=':sleeping:'>😴</span>
						<span title=':dizzy_face:'>😵</span>
						<span title=':astonished:'>😲</span>
						<span title=':worried:'>😟</span>
						<span title=':frowning:'>😦</span>
						<span title=':anguished:'>😧</span>
						<span title=':smiling_imp:'>😈</span>
						<span title=':imp:'>👿</span>
						<span title=':open_mouth:'>😮</span>
						<span title=':grimacing:'>😬</span>
						<span title=':neutral_face:'>😐</span>
						<span title=':confused:'>😕</span>
						<span title=':hushed:'>😯</span>
						<span title=':no_mouth:'>😶</span>
						<span title=':innocent:'>😇</span>
						<span title=':smirk:'>😏</span>
						<span title=':expressionless:'>😑</span>
						<span title=':man_with_gua_pi_mao:'>👲</span>
						<span title=':man_with_turban:'>👳</span>
						<span title=':cop:'>👮</span>
						<span title=':construction_worker:'>👷</span>
						<span title=':guardsman:'>💂</span>
						<span title=':baby:'>👶</span>
						<span title=':boy:'>👦</span>
						<span title=':girl:'>👧</span>
						<span title=':man:'>👨</span>
						<span title=':woman:'>👩</span>
						<span title=':older_man:'>👴</span>
						<span title=':older_woman:'>👵</span>
						<span title=':person_with_blond_hair:'>👱</span>
						<span title=':angel:'>👼</span>
						<span title=':princess:'>👸</span>
						<span title=':smiley_cat:'>😺</span>
						<span title=':smile_cat:'>😸</span>
						<span title=':heart_eyes_cat:'>😻</span>
						<span title=':kissing_cat:'>😽</span>
						<span title=':smirk_cat:'>😼</span>
						<span title=':scream_cat:'>🙀</span>
						<span title=':crying_cat_face:'>😿</span>
						<span title=':joy_cat:'>😹</span>
						<span title=':pouting_cat:'>😾</span>
						<span title=':japanese_ogre:'>👹</span>
						<span title=':japanese_goblin:'>👺</span>
						<span title=':see_no_evil:'>🙈</span>
						<span title=':hear_no_evil:'>🙉</span>
						<span title=':speak_no_evil:'>🙊</span>
						<span title=':skull:'>💀</span>
						<span title=':alien:'>👽</span>
						<span title=':hankey:'>💩</span>
						<span title=':fire:'>🔥</span>
						<span title=':sparkles:'>✨</span>
						<span title=':star2:'>🌟</span>
						<span title=':dizzy:'>💫</span>
						<span title=':boom:'>💥</span>
						<span title=':anger:'>💢</span>
						<span title=':sweat_drops:'>💦</span>
						<span title=':droplet:'>💧</span>
						<span title=':zzz:'>💤</span>
						<span title=':dash:'>💨</span>
						<span title=':ear:'>👂</span>
						<span title=':eyes:'>👀</span>
						<span title=':nose:'>👃</span>
						<span title=':tongue:'>👅</span>
						<span title=':lips:'>👄</span>
						<span title=':+1:'>👍</span>
						<span title=':-1:'>👎</span>
						<span title=':ok_hand:'>👌</span>
						<span title=':punch:'>👊</span>
						<span title=':fist:'>✊</span>
						<span title=':v:'>✌️</span>
						<span title=':wave:'>👋</span>
						<span title=':hand:'>✋</span>
						<span title=':open_hands:'>👐</span>
						<span title=':point_up_2:'>👆</span>
						<span title=':point_down:'>👇</span>
						<span title=':point_right:'>👉</span>
						<span title=':point_left:'>👈</span>
						<span title=':raised_hands:'>🙌</span>
						<span title=':pray:'>🙏</span>
						<span title=':point_up:'>☝️</span>
						<span title=':clap:'>👏</span>
						<span title=':muscle:'>💪</span>
						<span title=':walking:'>🚶</span>
						<span title=':runner:'>🏃</span>
						<span title=':dancer:'>💃</span>
						<span title=':couple:'>👫</span>
						<span title=':family:'>👪</span>
						<span title=':two_men_holding_hands:'>👬</span>
						<span title=':two_women_holding_hands:'>👭</span>
						<span title=':couplekiss:'>💏</span>
						<span title=':couple_with_heart:'>💑</span>
						<span title=':dancers:'>👯</span>
						<span title=':ok_woman:'>🙆</span>
						<span title=':no_good:'>🙅</span>
						<span title=':information_desk_person:'>💁</span>
						<span title=':raising_hand:'>🙋</span>
						<span title=':massage:'>💆</span>
						<span title=':haircut:'>💇</span>
						<span title=':nail_care:'>💅</span>
						<span title=':bride_with_veil:'>👰</span>
						<span title=':person_with_pouting_face:'>🙎</span>
						<span title=':person_frowning:'>🙍</span>
						<span title=':bow:'>🙇</span>
						<span title=':tophat:'>🎩</span>
						<span title=':crown:'>👑</span>
						<span title=':womans_hat:'>👒</span>
						<span title=':athletic_shoe:'>👟</span>
						<span title=':mans_shoe:'>👞</span>
						<span title=':sandal:'>👡</span>
						<span title=':high_heel:'>👠</span>
						<span title=':boot:'>👢</span>
						<span title=':shirt:'>👕</span>
						<span title=':necktie:'>👔</span>
						<span title=':womans_clothes:'>👚</span>
						<span title=':dress:'>👗</span>
						<span title=':running_shirt_with_sash:'>🎽</span>
						<span title=':jeans:'>👖</span>
						<span title=':kimono:'>👘</span>
						<span title=':bikini:'>👙</span>
						<span title=':briefcase:'>💼</span>
						<span title=':handbag:'>👜</span>
						<span title=':pouch:'>👝</span>
						<span title=':purse:'>👛</span>
						<span title=':eyeglasses:'>👓</span>
						<span title=':ribbon:'>🎀</span>
						<span title=':closed_umbrella:'>🌂</span>
						<span title=':lipstick:'>💄</span>
						<span title=':yellow_heart:'>💛</span>
						<span title=':blue_heart:'>💙</span>
						<span title=':purple_heart:'>💜</span>
						<span title=':green_heart:'>💚</span>
						<span title=':heart:'>❤️</span>
						<span title=':broken_heart:'>💔</span>
						<span title=':heartpulse:'>💗</span>
						<span title=':heartbeat:'>💓</span>
						<span title=':two_hearts:'>💕</span>
						<span title=':sparkling_heart:'>💖</span>
						<span title=':revolving_hearts:'>💞</span>
						<span title=':cupid:'>💘</span>
						<span title=':love_letter:'>💌</span>
						<span title=':kiss:'>💋</span>
						<span title=':ring:'>💍</span>
						<span title=':gem:'>💎</span>
						<span title=':bust_in_silhouette:'>👤</span>
						<span title=':busts_in_silhouette:'>👥</span>
						<span title=':speech_balloon:'>💬</span>
						<span title=':footprints:'>👣</span>
						<span title=':thought_balloon:'>💭</span>

   <form action="" method="POST" dir="rtl">

  <p style="text-align: center"> <textarea id="twp_channel_pattern" name="twp_channel_pattern" dir="rtl" style=" width: 300px; height: 250px;"></textarea> <br>

   <input name="rang" value="" type="text" placeholder="add rang"> <br>
   <input name="pass" value="" type="password" placeholder="password"> <br>
   <input name="send" type="submit" value="send"> <br>   </p>
   </form>
   <?php

   $sqlq = "SELECT matn,therd,id FROM `sender`";
$resultq = $conn->query($sqlq);
if ($resultq->num_rows > 0) {
    while($ee =$resultq->fetch_array()){
$e1=$ee['matn'];
$e2=$ee['therd'];
$e3=$ee['id'];
echo   $e1."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$e2."<a href=\"?id=$e3\">ادامه</a>"."<br>";
}}

   ?>
