<?php

namespace SBBCodeParser;

class Exception_InvalidNesting extends Exception
{
}