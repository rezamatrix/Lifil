<?php

namespace SBBCodeParser;

class Exception_MissingEndTag extends Exception
{
}