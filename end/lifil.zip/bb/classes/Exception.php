<?php

namespace SBBCodeParser;

class Exception extends \Exception
{
}