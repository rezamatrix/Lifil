<?php
include("ses.php");
date_default_timezone_set('Asia/Tehran');
$con=mysqli_connect('localhost','root','reza1375','bit');
$web="https://bitsoftware.ir";
$token= "383934933:AAEQo3QohT9isMLermgtMIUVsljvGfgwm8s";   
?>