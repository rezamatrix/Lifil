</div>
    </div>
    </div>
    </div>
<!-- build:js scripts/app.html.js -->
<!-- jQuery
      -->
<!-- Bootstrap -->
          <script src="../libs/jquery/jquery/dist/jquery.js"></script>
    <script src="../libs/jquery/tether/dist/js/tether.min.js"></script>
    <script src="../libs/jquery/bootstrap/dist/js/bootstrap.js"></script>
<!-- core -->
    <script src="../libs/jquery/underscore/underscore-min.js"></script>
    <script src="../libs/jquery/jQuery-Storage-API/jquery.storageapi.min.js"></script>
    <script src="../libs/jquery/PACE/pace.min.js"></script>

    <script src="../scripts/config.lazyload.js"></script>

    <script src="../scripts/palette.js"></script>
    <script src="../scripts/ui-load.js"></script>
    <script src="../scripts/ui-jp.js"></script>
    <script src="../scripts/ui-include.js"></script>
    <script src="../scripts/ui-device.js"></script>
    <script src="../scripts/ui-form.js"></script>
    <script src="../scripts/ui-nav.js"></script>
    <script src="../scripts/ui-screenfull.js"></script>
    <script src="../scripts/ui-scroll-to.js"></script>
    <script src="../scripts/ui-toggle-class.js"></script>

    <script src="../scripts/app.js"></script>

    <!-- ajax -->
    <script src="../libs/jquery/jquery-pjax/jquery.pjax.js"></script>
    <script src="../scripts/ajax.js"></script>
    <script>
$('.carousel').carousel({
    interval: 2500
})
</script>
        <script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
});
</script>
<!-- endbuild -->
</body>
</html>
