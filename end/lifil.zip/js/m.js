



              function select(nummnue)
{
 if(nummnue==1){
  document.getElementById('idl').setAttribute('style','visibility: visible;');
      document.getElementById('idl').removeAttribute('hidden');
  }  else{
  document.getElementById('idl').setAttribute('style','visibility: hidden;');
    document.getElementById('idl').setAttribute('hidden','hidden');

  }
   if(nummnue==2){
  document.getElementById('idll').setAttribute('style','visibility: visible;');
      document.getElementById('idll').removeAttribute('hidden');
  }  else{
  document.getElementById('idll').setAttribute('style','visibility: hidden;');
    document.getElementById('idll').setAttribute('hidden','hidden');

  }
   if(nummnue==3){
  document.getElementById('idlll').setAttribute('style','visibility: visible;');
    document.getElementById('idlll').removeAttribute('hidden');
  } else{
  document.getElementById('idlll').setAttribute('style','visibility: hidden;');
    document.getElementById('idlll').setAttribute('hidden','hidden');

  }
   if(nummnue==4){
  document.getElementById('idvl').setAttribute('style','visibility: visible;');
    document.getElementById('idvl').removeAttribute('hidden');
  }else{
  document.getElementById('idvl').setAttribute('style','visibility: hidden;');
     document.getElementById('idvl').setAttribute('hidden','hidden');
  }

}

function img(urlimg)
{
document.getElementById('dvl').setAttribute('style','visibility: visible;');
document.getElementById('imgl').setAttribute('src',urlimg);

}
function imghiden()
{
document.getElementById('dvl').setAttribute('style','visibility: hidden;');
}


function frer(wer)
{
    if(wer==1){
document.getElementById('f1').setAttribute('style','visibility: visible;');
document.getElementById('f1a').setAttribute('style','visibility: visible;');
document.getElementById('f1b').setAttribute('style','visibility: hidden;');
document.getElementById('f1b').setAttribute('hidden','hidden');
    document.getElementById('f1').removeAttribute('hidden');
    document.getElementById('f1a').removeAttribute('hidden');

}
 if(wer==2){
document.getElementById('f2').setAttribute('style','visibility: visible;');
document.getElementById('f2a').setAttribute('style','visibility: visible;');
document.getElementById('f2b').setAttribute('style','visibility: hidden;');
     document.getElementById('f2').removeAttribute('hidden');
     document.getElementById('f2a').removeAttribute('hidden');
     document.getElementById('f2b').setAttribute('hidden','hidden');
}

 if(wer==3){
document.getElementById('f3').setAttribute('style','visibility: visible;');
document.getElementById('f3a').setAttribute('style','visibility: visible;');
document.getElementById('f3b').setAttribute('style','visibility: hidden;');
    document.getElementById('f3').removeAttribute('hidden');
    document.getElementById('f3a').removeAttribute('hidden');
    document.getElementById('f3b').setAttribute('hidden','hidden');
}
 if(wer==4){
document.getElementById('f4').setAttribute('style','visibility: visible;');
document.getElementById('f4a').setAttribute('style','visibility: visible;');
document.getElementById('f4b').setAttribute('style','visibility: hidden;');
     document.getElementById('f4').removeAttribute('hidden');
     document.getElementById('f4a').removeAttribute('hidden');
     document.getElementById('f4b').setAttribute('hidden','hidden');
}
}

   function t()
{
document.getElementById('dvlq').setAttribute('style','visibility: visible;');

}
function th()
{
document.getElementById('dvlq').setAttribute('style','visibility: hidden;');
}









