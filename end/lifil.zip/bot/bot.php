<?php
include("conf.php");
header('Content-Type: text/html; charset=utf-8');
$message= file_get_contents("php://input");
$arrayMessage= json_decode($message, true);

$chat_id= $arrayMessage['message']['from']['id'];
$command= $arrayMessage['message']['text'];
@$user_phone = $arrayMessage['message']['contact']['phone_number'];
$user= $arrayMessage['message']['from']['username'];
if(strlen($user_phone)>5){


ph($conn,$chat_id,$user_phone);
 $rey=getuser($conn,$chat_id);
 $str = "9".ltrim($user_phone, '98');

 $sql = "UPDATE `user` SET `tauh` = '1'  WHERE `user` = '$rey' and `tell` = '$str';";
 $conn->query($sql);
  $text=urlencode( "کد ورود به اکانت دو مرحله ای فعال شد");
text($text,$jsonPoets,$token,$chat_id);
}

if($command == '/start' and getstep($conn,$chat_id)==0){
    $sql = "SELECT *FROM `bott`WHERE `chatid` = '$chat_id'";
$result = $conn->query($sql);
if ($result->num_rows <= 0) {
$sql = "INSERT INTO `bott` (`chatid`, `step`, `tag`) VALUES ('$chat_id',  '0', '');";
$conn->query($sql);

    }
$poets= array('keyboard' => array(array('اتصال اکانت'), array('قطع اتصال'), array('حذف کیبورد'), array(array("text" => "فعال سازی ورود دو مرحله ای","request_contact" => true ))));
$jsonPoets= json_encode($poets);
$text= "خوش آمدید";
text($text,$jsonPoets,$token,$chat_id);
}
if($command == 'اتصال اکانت'and getstep($conn,$chat_id)==0){
$poets= array('keyboard' => array(array('بازگشت')));
$jsonPoets= json_encode($poets);
$text= "";
text($text,$jsonPoets,$token,$chat_id);
tag($conn,$chat_id,'اتصال اکانت');
step($conn,$chat_id,1);

}
 if($command=='قطع اتصال'&& getstep($conn,$chat_id)==0){

 $rey=getuser($conn,$chat_id);
 $str = "9".ltrim(getph($conn,$chat_id), '98');
 $sql = "UPDATE `user` SET `tauh` = '0'  WHERE `user` = '$rey' and `tell` = '$str';";
 $conn->query($sql);
  $sql = "UPDATE `user` SET `chatid` = ' '  WHERE `user` = '$rey' and `tell` = '$str';";
 $conn->query($sql);
  $sql = "UPDATE `bott` SET `user` = ''  WHERE `chatid` = '$chat_id' ;";
 $conn->query($sql);
 $text= "اتصال قطع شد";
text($text,$jsonPoets,$token,$chat_id);
 ph($conn,$chat_id,"");
 }
if(@getstep($conn,$chat_id)==1 and gettag($conn,$chat_id)=='اتصال اکانت'){

if($command == 'بازگشت'){
$poets= array('keyboard' => array(array('اتصال اکانت'), array('قطع اتصال'), array('حذف کیبورد'), array(array("text" => "فعال سازی ورود دو مرحله ای","request_contact" => true ))));
$jsonPoets= json_encode($poets);
$text= "خوش آمدید";
text($text,$jsonPoets,$token,$chat_id);
tag($conn,$chat_id,'');
step($conn,$chat_id,0);
}
if(strlen($command)>2){
    $ss=$conn->real_escape_string($command);

        if(!preg_match( "/[:,\\. ^ ? ; & | ! ' # $ % ^ *( )   € < > \\n\\r\\t\\s]+/", $ss )){

 $re=getpass($conn,$ss);

 if(strlen($re)>1){

  des($conn,$chat_id,$re.','.$ss);
step($conn,$chat_id,2);
 } else{
     $poets= array('keyboard' => array(array('بازگشت')));
$jsonPoets= json_encode($poets);
 $text= "این نام کار بری اشتباه است";
    text($text,$jsonPoets,$token,$chat_id);
 }
}
}
if(@getstep($conn,$chat_id)==1 and gettag($conn,$chat_id)=='اتصال اکانت'){
$poets= array('keyboard' => array(array('بازگشت')));
$jsonPoets= json_encode($poets);
$text= "نام کاربری اکانت خود را وارد کنید.";
text($text,$jsonPoets,$token,$chat_id);
} }

if(@getstep($conn,$chat_id)==2 and gettag($conn,$chat_id)=='اتصال اکانت'){

$rtd=getdes($conn,$chat_id);
$arey=explode(',',$rtd);

if($arey['0']==md5(base64_encode(base64_encode($command)))  ){
  if(strlen(getch($conn,$arey['1']))<3 and regetch($conn,$chat_id)==0){
    $user=$arey['1'];
 $sql = "UPDATE `user` SET `chatid` = '$chat_id'  WHERE `user` = '$user';";
          $conn->query($sql);
                    $sql = "UPDATE `bott` SET `user` = '$user'  WHERE `chatid` = $chat_id;";
          $conn->query($sql);
          $text= "اتصال انجام شد";
text($text,$jsonPoets,$token,$chat_id);
$poets= array('keyboard' => array(array('اتصال اکانت'), array('قطع اتصال'), array('حذف کیبورد'), array(array("text" => "فعال سازی ورود دو مرحله ای","request_contact" => true ))));
$jsonPoets= json_encode($poets);
$text= "خوش آمدید";
text($text,$jsonPoets,$token,$chat_id);
tag($conn,$chat_id,'');
des($conn,$chat_id,'');
step($conn,$chat_id,0);
}
 else {
    $poets= array('keyboard' => array(array('اتصال اکانت'), array('قطع اتصال'), array('حذف کیبورد'), array(array("text" => "فعال سازی ورود دو مرحله ای","request_contact" => true ))));
  $jsonPoets= json_encode($poets);
 $text= "این اکانت قبلا متصل شده است";
    text($text,$jsonPoets,$token,$chat_id);
    tag($conn,$chat_id,'');
des($conn,$chat_id,'');
step($conn,$chat_id,0);
}
}
else {
$poets= array('keyboard' => array(array('بازگشت')));
$jsonPoets= json_encode($poets);
 $text2= "این گذرواژه اشتباه می باشد";
    text($text2,$jsonPoets,$token,$chat_id);
}
 if($command == 'بازگشت'){
$poets= array('keyboard' => array(array('اتصال اکانت'), array('قطع اتصال'), array('حذف کیبورد'), array(array("text" => "فعال سازی ورود دو مرحله ای","request_contact" => true ))));
$jsonPoets= json_encode($poets);
$text= "خوش آمدید";
text($text,$jsonPoets,$token,$chat_id);
tag($conn,$chat_id,'');
des($conn,$chat_id,'');
step($conn,$chat_id,0);
}
if(@getstep($conn,$chat_id)==2 and gettag($conn,$chat_id)=='اتصال اکانت'){
 $poets= array('keyboard' => array(array('بازگشت')));
$jsonPoets= json_encode($poets);
$text= "گذرواژه خود را وارد کنید";
text($text,$jsonPoets,$token,$chat_id);
} }
function text($textin,$mark,$token,$chat_id){
    $url= "https://api.telegram.org/bot".$token."/sendMessage?chat_id=".$chat_id."&text=".$textin."&reply_markup=".$mark;
    file_get_contents($url);
}
function step($conn,$chat_id,$stepz){
          $sql = "UPDATE `bott` SET `step` = '$stepz'  WHERE `chatid` = $chat_id;";
          $conn->query($sql);
 }
 function des($conn,$chat_id,$desz){
          $sql = "UPDATE `bott` SET `des` = '$desz'  WHERE `chatid` = $chat_id;";
          $conn->query($sql);
 }
  function ph($conn,$chat_id,$phz){
          $sql = "UPDATE `bott` SET `ph` = '$phz'  WHERE `chatid` = $chat_id;";
          $conn->query($sql);
 }
  function tag($conn,$chat_id,$tagz){
          $sql = "UPDATE `bott` SET `tag` = '$tagz'  WHERE `chatid` = $chat_id;";
          $conn->query($sql);
 }
  function gettag($conn,$chat_id){
         $sql = "SELECT *FROM `bott`WHERE `chatid` = '$chat_id'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
$row = $result->fetch_assoc();
          $tag=$row['tag'];
    }
    return $tag;
 }
   function getuser($conn,$chat_id){
         $sql = "SELECT *FROM `bott`WHERE `chatid` = '$chat_id'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
$row = $result->fetch_assoc();
          $user=$row['user'];
    }
    return $user;
 }
   function getstep($conn,$chat_id){
         $sql = "SELECT *FROM `bott`WHERE `chatid` = '$chat_id'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
$row = $result->fetch_assoc();
          $tag=$row['step'];
    }
    return $tag;
 }
    function getdes($conn,$chat_id){
         $sql = "SELECT *FROM `bott`WHERE `chatid` = '$chat_id'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
$row = $result->fetch_assoc();
          $tag=$row['des'];
    }
    return $tag;
 }
     function getph($conn,$chat_id){
         $sql = "SELECT *FROM `bott`WHERE `chatid` = '$chat_id'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
$row = $result->fetch_assoc();
          $tag=$row['ph'];
    }
    return $tag;
 }
     function getpass($conn,$ss){
$sql = "SELECT password FROM `user` WHERE `user` = '$ss'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
 $row = $result->fetch_assoc();
    $pass=$row['password'];
}
    return $pass;
 }
      function getch($conn,$ss){
$sql = "SELECT chatid FROM `user` WHERE `user` = '$ss'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
 $row = $result->fetch_assoc();
    $pass=$row['chatid'];
}
    return $pass;
 }
       function regetch($conn,$ss){
$sql = "SELECT id FROM `user` WHERE `chatid` = '$ss'";
$result = $conn->query($sql);

    return $result->num_rows;
 }

?>