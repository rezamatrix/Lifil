<?php
include("../config/conf.php");


if(isset($_SESSION['pass']) and isset($_SESSION['user'])){
echo "ok";

 }
 //if(isset($_COOKIE['pass']) and isset($_COOKIE['user'])){
//echo "ok";

// }
?>