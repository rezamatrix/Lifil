<?php
 include("../config/conf.php");
 $_SESSION['pass']="";
 header("location:lock.php") ;
?>