<?php
 include("../config/conf.php");
session_destroy() ;
 header("location:../index.php") ;

?>